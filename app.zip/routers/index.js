const router = require("express").Router()
const userRouter = require("./userRouter")
const databaseRouter = require("./databaseRouter")

router.use("/user", userRouter)
router.use("/database", databaseRouter)
module.exports = router