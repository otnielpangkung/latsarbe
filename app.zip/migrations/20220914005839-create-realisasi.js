'use strict';
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('Realisasis', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      noDokumen: {
        type: Sequelize.STRING, unique:true
      },
      GroupId: {
        type: Sequelize.INTEGER
      },
      KorId: {
        type: Sequelize.INTEGER
      },
      KegiatanId: {
        type: Sequelize.INTEGER
      },
      KomponenId: {
        type: Sequelize.INTEGER
      },
      RoId: {
        type: Sequelize.INTEGER
      },
      dateTransaction: {
        type: Sequelize.DATE
      },
      sifatPembayaran: {
        type: Sequelize.STRING
      },
      UserId: { type: Sequelize.INTEGER, allowNull: false},
      jenisPembayaran: {
        type: Sequelize.STRING
      },
      pagu: {
        type: Sequelize.BIGINT
      },
      amount: {
        type: Sequelize.BIGINT
      },
      balancePagu: {
        type: Sequelize.BIGINT
      },
      suratTugas: {type: Sequelize.BIGINT, defaultValue: false},
      daftarNominatif: {type: Sequelize.BIGINT, defaultValue: false},
      copySurat: {type: Sequelize.BIGINT, defaultValue: false},
      kwuitansi: {type: Sequelize.BIGINT, defaultValue: false},
      dpr: {type: Sequelize.BIGINT, defaultValue: false},
      spd: {type: Sequelize.BIGINT, defaultValue: false},
      absen: {type: Sequelize.BIGINT, defaultValue: false},
      tiket: {type: Sequelize.BIGINT, defaultValue: false},
      hotel: {type: Sequelize.BIGINT, defaultValue: false},
      lainnya: {type: Sequelize.BIGINT, defaultValue: false},
      invoice: {type: Sequelize.BIGINT, defaultValue: false},
      kwuitansiPembayaran: {type: Sequelize.BIGINT, defaultValue: false},
      stempel: {type: Sequelize.BIGINT, defaultValue: false},
      fakturPajak: {type: Sequelize.BIGINT, defaultValue: false},
      ssp: {type: Sequelize.BIGINT, defaultValue: false},
      ttdPetugas: {type: Sequelize.BIGINT, defaultValue: false},
      suratPenawaran: {type: Sequelize.BIGINT, defaultValue: false},
      spk: {type: Sequelize.BIGINT, defaultValue: false},
      bast: {type: Sequelize.BIGINT, defaultValue: false},
      bap: {type: Sequelize.BIGINT, defaultValue: false},
      sk: {type: Sequelize.BIGINT, defaultValue: false},
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('Realisasis');
  }
};